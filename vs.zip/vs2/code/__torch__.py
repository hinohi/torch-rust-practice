class Module(Module):
  __parameters__ = ["bias__6", "weight__3", "bias", "weight__5", "bias__2", "weight", "weight__7", "bias__4", ]
  __buffers__ = []
  bias__6 : Tensor
  weight__3 : Tensor
  bias : Tensor
  weight__5 : Tensor
  bias__2 : Tensor
  weight : Tensor
  weight__7 : Tensor
  bias__4 : Tensor
