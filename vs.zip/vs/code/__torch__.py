class Module(Module):
  __parameters__ = ["conv2d_2|weight", "linear_1|weight", "conv2d_2|bias", "linear_1|bias", "linear_2|bias", "conv2d_1|weight", "linear_2|weight", "conv2d_1|bias", ]
  __buffers__ = []
  __annotations__ = []
  __annotations__["conv2d_2|weight"] = Tensor
  __annotations__["linear_1|weight"] = Tensor
  __annotations__["conv2d_2|bias"] = Tensor
  __annotations__["linear_1|bias"] = Tensor
  __annotations__["linear_2|bias"] = Tensor
  __annotations__["conv2d_1|weight"] = Tensor
  __annotations__["linear_2|weight"] = Tensor
  __annotations__["conv2d_1|bias"] = Tensor
